# GoodRichTea
Static website for goodrich tea
